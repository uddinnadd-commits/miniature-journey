package com.tooperfect.registry;

import com.tooperfect.TooPerfect;
import com.tooperfect.block.BleedingGrassBlock;
import com.tooperfect.block.VoidBlock;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TooPerfect.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TooPerfect.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TooPerfect.MODID);

    /** The cracked glass "sky" that sits high above the world. */
    public static final RegistryObject<Block> SKY_GLASS = block("sky_glass", () -> new GlassBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(0.3F)
                    .sound(SoundType.GLASS)
                    .noOcclusion()
                    .isValidSpawn(ModBlocks::noSpawn)
                    .isRedstoneConductor(ModBlocks::no)
                    .isSuffocating(ModBlocks::no)
                    .isViewBlocking(ModBlocks::no)));

    /** The thick black void revealed where the glass has broken. */
    public static final RegistryObject<Block> VOID_BLOCK = block("void_block", () -> new VoidBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(-1.0F, 3600000.0F)
                    .noOcclusion()
                    .isValidSpawn(ModBlocks::noSpawn)
                    .isRedstoneConductor(ModBlocks::no)
                    .isSuffocating(ModBlocks::no)
                    .isViewBlocking(ModBlocks::no)));

    public static final RegistryObject<Block> BLEEDING_GRASS = block("bleeding_grass", () -> new BleedingGrassBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(0.6F).sound(SoundType.GRASS)));

    public static final RegistryObject<Block> TAINTED_EARTH = block("tainted_earth", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN).strength(0.6F).sound(SoundType.MUD)));

    public static final RegistryObject<Block> ROTTED_LOG = block("rotted_log", () -> new RotatedPillarBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(1.5F).sound(SoundType.WOOD)));

    public static final RegistryObject<Block> ROTTED_LEAVES = block("rotted_leaves", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN).strength(0.3F).sound(SoundType.MOSS)));

    public static final RegistryObject<Block> CORRUPTED_STONE = block("corrupted_stone", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(1.8F, 6.0F).sound(SoundType.STONE)));

    /** Anything else turns into this: a block covered in eyes. */
    public static final RegistryObject<Block> WRONG_BLOCK = block("wrong_block", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(2.0F, 6.0F).sound(SoundType.SCULK)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + TooPerfect.MODID))
            .icon(() -> new ItemStack(BLEEDING_GRASS.get()))
            .displayItems((params, output) -> BLOCKS.getEntries().forEach(entry -> output.accept(entry.get())))
            .build());

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> registered = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(registered.get(), new Item.Properties()));
        return registered;
    }

    private static boolean no(BlockState state, BlockGetter level, BlockPos pos) {
        return false;
    }

    private static Boolean noSpawn(BlockState state, BlockGetter level, BlockPos pos, EntityType<?> type) {
        return Boolean.FALSE;
    }

    private ModBlocks() {}
}
