package com.tooperfect;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.tooperfect.world.Progression;
import com.tooperfect.world.WorldState;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /tooperfect stage <0-4>  and  /tooperfect info   (op level 2). Handy for testing each stage. */
@Mod.EventBusSubscriber(modid = TooPerfect.MODID)
public final class ModCommands {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("tooperfect")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.literal("stage")
                                .then(Commands.argument("stage", IntegerArgumentType.integer(0, Progression.MAX_STAGE))
                                        .executes(ctx -> setStage(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "stage")))))
                        .then(Commands.literal("info")
                                .executes(ctx -> info(ctx.getSource()))));
    }

    private static int setStage(CommandSourceStack source, int stage) {
        ServerLevel overworld = source.getServer().overworld();
        WorldState state = WorldState.get(overworld);
        state.ticks = (long) stage * Progression.stageTicks();
        state.setDirty();
        source.sendSystemMessage(Component.literal(
                "Too Perfect: stage " + stage + " - " + Progression.NAMES[stage]
                        + ". Blocks already changed do not change back."));
        return 1;
    }

    private static int info(CommandSourceStack source) {
        ServerLevel overworld = source.getServer().overworld();
        WorldState state = WorldState.get(overworld);
        int stage = Progression.stage(state.ticks);
        int percent = Math.round(Progression.progress(state.ticks) * 100.0F);
        source.sendSystemMessage(Component.literal(
                "Too Perfect: stage " + stage + " - " + Progression.NAMES[stage] + " (" + percent + "% through)."));
        return 1;
    }

    private ModCommands() {}
}
