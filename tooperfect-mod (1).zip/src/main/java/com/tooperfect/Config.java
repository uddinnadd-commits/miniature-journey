package com.tooperfect;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue STAGE_MINUTES;
    public static final ForgeConfigSpec.BooleanValue PEACEFUL_FLOWERS;
    public static final ForgeConfigSpec.BooleanValue SKY_BREAKS;
    public static final ForgeConfigSpec.BooleanValue BLOCK_CORRUPTION;
    public static final ForgeConfigSpec.BooleanValue MOB_MUTATION;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Too Perfect settings").push("horror");

        STAGE_MINUTES = b.comment(
                "Real minutes (counted only while a player is online) that each of the first four stages lasts.",
                "15 means roughly an hour before the final stage begins. Use /tooperfect stage <0-4> to skip around.")
                .defineInRange("stageMinutes", 15.0D, 0.1D, 1440.0D);

        PEACEFUL_FLOWERS = b.comment("Flowers keep blooming around players during the peaceful stages.")
                .define("peacefulFlowers", true);

        SKY_BREAKS = b.comment("Build the glass sky and let it break into the void (stage 2 and later).")
                .define("skyBreaks", true);

        BLOCK_CORRUPTION = b.comment("Grass, trees and then every block corrupt (stage 3 and later). Edits your world!")
                .define("blockCorruption", true);

        MOB_MUTATION = b.comment("Animals and villagers mutate and hunt the player (stage 3 and later).")
                .define("mobMutation", true);

        b.pop();
        SPEC = b.build();
    }

    private Config() {}
}
