package com.tooperfect.client;

import java.util.Random;

/** The player's inner voice. Text is picked per stage; the overlay types it out above the hotbar. */
public final class Thoughts {
    private static final Random RNG = new Random();

    private static final String[] ENTRY = {
            "What a beautiful morning.",
            "It's too perfect.",
            "...the sky is cracking.",
            "It was never peaceful. It was waiting.",
            "Everything is turning into something else."
    };

    private static final String[][] POOL = {
            { // 0 Serenity
                    "The flowers are everywhere. I don't remember planting any.",
                    "It's so quiet. In a good way, I think.",
                    "Everything is exactly where it should be.",
                    "I feel safe here.",
                    "Not a single cloud today.",
                    "Even the animals seem happy to see me.",
                    "I could stay here forever.",
                    "Why would I ever leave?"
            },
            { // 1 Too Perfect
                    "They haven't stopped looking at me.",
                    "Do they ever blink?",
                    "There's no wind. There hasn't been wind for a while.",
                    "The sun hasn't moved. Has it?",
                    "When did the night stop coming?",
                    "Even the cows are facing me.",
                    "Don't turn around. Don't turn around.",
                    "It's too quiet. Nothing is even breathing.",
                    "I keep telling myself it's beautiful."
            },
            { // 2 Fracture
                    "That isn't sky. That's glass.",
                    "I can hear it cracking.",
                    "Something is behind the glass. Something big.",
                    "It's not blue behind it. It's not anything.",
                    "The light is leaking away.",
                    "Pieces are falling. Nobody else is looking up.",
                    "How thick is that void?",
                    "It's getting darker where the glass is gone."
            },
            { // 3 Decay
                    "The grass is bleeding.",
                    "What's wrong with the trees?",
                    "That cow is not a cow anymore.",
                    "It smells like copper out here.",
                    "They're not looking anymore. They're hunting.",
                    "Everything is rotting from the inside.",
                    "The branches are growing toward me.",
                    "I should have left when it was beautiful."
            },
            { // 4 Unmaking
                    "Every block is wrong.",
                    "The ground is watching me too.",
                    "Nothing here was ever real.",
                    "Run. Run where?",
                    "I don't think this was ever a world.",
                    "It's all eyes. It was always eyes.",
                    "Please wake up. Please wake up.",
                    "It's just me and whatever made this."
            }
    };

    private static final String[][] STARE = {
            {"It's looking at me. How sweet.", "Hello to you too.", "Why does it follow me with its eyes?"},
            {"Stop looking at me.", "It hasn't moved. Not once.", "Its eyes are wrong."},
            {"Its head turned too far.", "Why is it still staring while the sky breaks?"},
            {"That's not hunger. That's recognition.", "It knows me.", "It's smiling. Cows can't smile."},
            {"It's not even pretending anymore.", "Whatever that was, it isn't anymore.", "Don't look back at it."}
    };

    public static String current = null;
    public static int age = 0;
    public static int total = 0;
    public static int ticksPerChar = 2;

    private static int cooldown = 160;
    private static int stareCooldown = 0;
    private static String last = "";

    public static void onStage(int stage) {
        show(ENTRY[clamp(stage)], stage);
        cooldown = nextDelay(stage);
    }

    public static void tick(int stage, boolean staringAtMob) {
        int s = clamp(stage);
        if (current != null) {
            age++;
            if (age > total) {
                current = null;
                cooldown = nextDelay(s);
            }
            return;
        }
        if (stareCooldown > 0) stareCooldown--;
        if (staringAtMob && stareCooldown == 0) {
            show(pick(STARE[s]), s);
            stareCooldown = 900;
            return;
        }
        if (cooldown > 0) {
            cooldown--;
        } else {
            show(pick(POOL[s]), s);
        }
    }

    /** How many characters are visible right now. */
    public static int typed() {
        if (current == null) return 0;
        return Math.min(current.length(), age / ticksPerChar);
    }

    public static void reset() {
        current = null;
        age = 0;
        cooldown = 160;
        stareCooldown = 0;
    }

    private static void show(String text, int stage) {
        current = text;
        age = 0;
        ticksPerChar = stage >= 4 ? 1 : 2;
        total = text.length() * ticksPerChar + 90;
        last = text;
    }

    private static int nextDelay(int stage) {
        return switch (stage) {
            case 0 -> 1100 + RNG.nextInt(900);
            case 1 -> 900 + RNG.nextInt(800);
            case 2 -> 800 + RNG.nextInt(700);
            case 3 -> 600 + RNG.nextInt(500);
            default -> 400 + RNG.nextInt(400);
        };
    }

    private static String pick(String[] pool) {
        String choice = pool[RNG.nextInt(pool.length)];
        if (pool.length > 1 && choice.equals(last)) {
            choice = pool[(java.util.Arrays.asList(pool).indexOf(choice) + 1) % pool.length];
        }
        return choice;
    }

    private static int clamp(int stage) {
        return Math.max(0, Math.min(4, stage));
    }

    private Thoughts() {}
}
