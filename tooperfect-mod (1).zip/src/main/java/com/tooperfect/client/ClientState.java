package com.tooperfect.client;

/** What the client knows about the world's stage. Plain numbers only, so it loads on any side. */
public final class ClientState {
    public static volatile int stage = -1;
    public static volatile float progress = 0.0F;
    /** Stage whose opening thought should be shown, or -1. */
    public static volatile int pendingEntry = -1;

    public static void apply(int newStage, float newProgress) {
        if (newStage != stage) {
            pendingEntry = newStage;
        }
        stage = newStage;
        progress = newProgress;
    }

    public static void reset() {
        stage = -1;
        progress = 0.0F;
        pendingEntry = -1;
    }

    private ClientState() {}
}
