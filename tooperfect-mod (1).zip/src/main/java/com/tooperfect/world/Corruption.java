package com.tooperfect.world;

import com.tooperfect.Config;
import com.tooperfect.TooPerfect;
import com.tooperfect.registry.ModBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Stage 3: grass bleeds, flowers wither, trees rot and grow wrong.
 * Stage 4: every other block turns into something bad.
 * Works by sampling random blocks around each player, so it spreads outward over time.
 */
public final class Corruption {

    public static void tick(ServerLevel level, List<ServerPlayer> players, int stage, float prog) {
        if (!Config.BLOCK_CORRUPTION.get()) return;

        int attempts = stage == 3 ? 24 + (int) (60.0F * prog) : 120 + (int) (160.0F * prog);
        int radius = stage == 3 ? 24 + (int) (16.0F * prog) : 40 + (int) (24.0F * prog);
        int budget = stage == 3 ? 24 : 150; // blocks changed per tick across all players

        RandomSource r = level.random;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (ServerPlayer p : players) {
            if (p.isSpectator()) continue;
            for (int i = 0; i < attempts && budget > 0; i++) {
                int x = p.getBlockX() + r.nextInt(radius * 2 + 1) - radius;
                int z = p.getBlockZ() + r.nextInt(radius * 2 + 1) - radius;
                pos.set(x, 64, z);
                if (!level.hasChunkAt(pos)) continue;

                int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                int y = r.nextInt(4) == 0
                        ? p.getBlockY() - 10 + r.nextInt(21)
                        : top - 1 - r.nextInt(10);
                if (y < level.getMinBuildHeight() || y >= SkyBreaker.SKY_Y - 1) continue;

                pos.set(x, y, z);
                BlockState state = level.getBlockState(pos);
                if (state.isAir()) continue;

                BlockState next = convert(level, pos, state, stage, r);
                if (next == null) continue;

                level.setBlock(pos, next, 2);
                budget--;
            }
        }
    }

    /** Returns the corrupted version of a block, or null to leave it alone. */
    private static BlockState convert(ServerLevel level, BlockPos pos, BlockState state, int stage, RandomSource r) {
        Block block = state.getBlock();
        if (isOurs(block)) return null;

        // ---- Stage 3 and later: decay ----
        if (state.is(Blocks.GRASS_BLOCK)) {
            return ModBlocks.BLEEDING_GRASS.get().defaultBlockState();
        }

        if (state.is(BlockTags.LOGS) && state.hasProperty(RotatedPillarBlock.AXIS)) {
            if (r.nextInt(8) == 0) growBranch(level, pos, r);
            return ModBlocks.ROTTED_LOG.get().defaultBlockState()
                    .setValue(RotatedPillarBlock.AXIS, state.getValue(RotatedPillarBlock.AXIS));
        }

        if (state.is(BlockTags.LEAVES)) {
            if (r.nextInt(6) == 0) growTendril(level, pos, r);
            return ModBlocks.ROTTED_LEAVES.get().defaultBlockState();
        }

        if (block instanceof DoublePlantBlock
                && (state.is(BlockTags.TALL_FLOWERS) || state.is(Blocks.TALL_GRASS) || state.is(Blocks.LARGE_FERN))) {
            return state.getValue(DoublePlantBlock.HALF) == DoubleBlockHalf.LOWER
                    ? Blocks.DEAD_BUSH.defaultBlockState()
                    : Blocks.AIR.defaultBlockState();
        }

        if (state.is(BlockTags.SMALL_FLOWERS) || state.is(Blocks.GRASS) || state.is(Blocks.FERN)) {
            return Blocks.DEAD_BUSH.defaultBlockState();
        }

        // ---- Stage 4: everything else ----
        if (stage >= 4) {
            if (state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(Blocks.COBBLESTONE)
                    || state.is(Blocks.MOSSY_COBBLESTONE) || state.is(Blocks.STONE_BRICKS)) {
                return ModBlocks.CORRUPTED_STONE.get().defaultBlockState();
            }
            if (state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(Blocks.GRAVEL) || state.is(Blocks.CLAY)) {
                return ModBlocks.TAINTED_EARTH.get().defaultBlockState();
            }
            if (!state.hasBlockEntity() && state.getDestroySpeed(level, pos) >= 0.0F && state.isSolidRender(level, pos)) {
                return ModBlocks.WRONG_BLOCK.get().defaultBlockState();
            }
        }
        return null;
    }

    /** A rotten log sprouts sideways out of the trunk, sometimes climbing again. */
    private static void growBranch(ServerLevel level, BlockPos pos, RandomSource r) {
        Direction dir = Direction.Plane.HORIZONTAL.getRandomDirection(r);
        BlockPos side = pos.relative(dir);
        if (!level.getBlockState(side).isAir()) return;
        level.setBlock(side, ModBlocks.ROTTED_LOG.get().defaultBlockState()
                .setValue(RotatedPillarBlock.AXIS, dir.getAxis()), 2);
        BlockPos up = side.above();
        if (r.nextBoolean() && level.getBlockState(up).isAir()) {
            level.setBlock(up, ModBlocks.ROTTED_LOG.get().defaultBlockState(), 2);
        }
    }

    /** Rotten strands hang down from the canopy. */
    private static void growTendril(ServerLevel level, BlockPos pos, RandomSource r) {
        int length = 1 + r.nextInt(4);
        BlockPos.MutableBlockPos cursor = pos.mutable();
        for (int i = 0; i < length; i++) {
            cursor.move(Direction.DOWN);
            if (!level.getBlockState(cursor).isAir()) break;
            level.setBlock(cursor, ModBlocks.ROTTED_LOG.get().defaultBlockState(), 2);
        }
    }

    private static boolean isOurs(Block block) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(block);
        return key != null && TooPerfect.MODID.equals(key.getNamespace());
    }

    private Corruption() {}
}
