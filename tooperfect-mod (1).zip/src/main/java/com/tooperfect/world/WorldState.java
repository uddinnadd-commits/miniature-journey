package com.tooperfect.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** How long the world has been "alive" with a player in it. Stored with the overworld. */
public class WorldState extends SavedData {
    private static final String NAME = "tooperfect_state";

    public long ticks = 0L;

    public static WorldState get(ServerLevel anyLevel) {
        ServerLevel overworld = anyLevel.getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(WorldState::load, WorldState::new, NAME);
    }

    public static WorldState load(CompoundTag tag) {
        WorldState state = new WorldState();
        state.ticks = tag.getLong("ticks");
        return state;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("ticks", this.ticks);
        return tag;
    }
}
