package com.tooperfect.world;

import com.tooperfect.Config;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.levelgen.Heightmap;

/** The world blooms: far more flowers than there should be, everywhere you look. */
public final class Flowers {
    private static final Block[] SMALL = {
            Blocks.DANDELION, Blocks.POPPY, Blocks.AZURE_BLUET, Blocks.OXEYE_DAISY, Blocks.CORNFLOWER,
            Blocks.LILY_OF_THE_VALLEY, Blocks.ALLIUM, Blocks.RED_TULIP, Blocks.ORANGE_TULIP,
            Blocks.WHITE_TULIP, Blocks.PINK_TULIP, Blocks.BLUE_ORCHID
    };
    private static final Block[] TALL = {
            Blocks.ROSE_BUSH, Blocks.PEONY, Blocks.LILAC, Blocks.SUNFLOWER
    };

    public static void tick(ServerLevel level, List<ServerPlayer> players, int stage) {
        if (!Config.PEACEFUL_FLOWERS.get()) return;
        int attempts = switch (stage) {
            case 0 -> 12;
            case 1 -> 20;
            case 2 -> 4;
            default -> 0;
        };
        if (attempts == 0) return;

        RandomSource r = level.random;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (ServerPlayer p : players) {
            for (int i = 0; i < attempts; i++) {
                int x = p.getBlockX() + r.nextInt(81) - 40;
                int z = p.getBlockZ() + r.nextInt(81) - 40;
                pos.set(x, 64, z);
                if (!level.hasChunkAt(pos)) continue;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                pos.set(x, y, z);
                if (!level.getBlockState(pos).isAir()) continue;
                if (!level.getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)) continue;

                int roll = r.nextInt(10);
                if (roll < 2 && level.isEmptyBlock(pos.above())) {
                    DoublePlantBlock.placeAt(level, TALL[r.nextInt(TALL.length)].defaultBlockState(), pos, 2);
                } else if (roll < 8) {
                    level.setBlock(pos, SMALL[r.nextInt(SMALL.length)].defaultBlockState(), 2);
                } else {
                    level.setBlock(pos, Blocks.GRASS.defaultBlockState(), 2);
                }
            }
        }
    }

    private Flowers() {}
}
