package com.tooperfect.world;

import com.tooperfect.Config;
import com.tooperfect.registry.ModBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds a cracked glass sky high above the world, then breaks it piece by piece.
 * Intact column : glass at SKY_Y.
 * Broken column : air at SKY_Y, a thick black void above it.
 */
public final class SkyBreaker {
    public static final int SKY_Y = 192;
    public static final int VOID_LAYERS = 6;
    private static final int RADIUS = 112;

    public static void tick(ServerLevel level, List<ServerPlayer> players, int stage, float prog) {
        if (!Config.SKY_BREAKS.get()) return;

        double coverage = switch (stage) {
            case 2 -> 0.9D * prog;
            case 3 -> 0.9D + 0.1D * prog;
            default -> 1.1D;
        };

        Block glassBlock = ModBlocks.SKY_GLASS.get();
        Block voidBlock = ModBlocks.VOID_BLOCK.get();
        BlockState glass = glassBlock.defaultBlockState();
        BlockState voidState = voidBlock.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();

        RandomSource r = level.random;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int budget = 24; // columns changed per tick, keeps the light engine happy

        for (ServerPlayer p : players) {
            for (int i = 0; i < 200 && budget > 0; i++) {
                int x = p.getBlockX() + r.nextInt(RADIUS * 2 + 1) - RADIUS;
                int z = p.getBlockZ() + r.nextInt(RADIUS * 2 + 1) - RADIUS;
                int dx = x - p.getBlockX();
                int dz = z - p.getBlockZ();
                if (dx * dx + dz * dz > RADIUS * RADIUS) continue;

                pos.set(x, SKY_Y, z);
                if (!level.hasChunkAt(pos)) continue;

                boolean wantBroken = cellRandom(x, z) < coverage;
                BlockState low = level.getBlockState(pos);
                boolean isBroken = level.getBlockState(pos.set(x, SKY_Y + 1, z)).is(voidBlock);

                if (wantBroken) {
                    if (isBroken) continue;
                    level.setBlock(pos.set(x, SKY_Y, z), air, 2);
                    for (int k = 1; k <= VOID_LAYERS; k++) {
                        level.setBlock(pos.set(x, SKY_Y + k, z), voidState, 2);
                    }
                    budget--;
                } else {
                    if (isBroken || low.is(glassBlock)) continue;
                    if (low.isAir()) {
                        level.setBlock(pos.set(x, SKY_Y, z), glass, 2);
                        budget--;
                    }
                }
            }
        }
    }

    /** Stable 0..1 value per roughly 5x5 "piece" of sky, offset every other row so the pieces look like shards. */
    private static double cellRandom(int x, int z) {
        int cz = Math.floorDiv(z, 5);
        int cx = Math.floorDiv(x + (cz & 1) * 2, 5);
        long h = (long) cx * 0x9E3779B97F4A7C15L ^ (long) cz * 0xC2B2AE3D27D4EB4FL ^ 0x5DEECE66DL;
        h = (h ^ (h >>> 30)) * 0xBF58476D1CE4E5B9L;
        h = (h ^ (h >>> 27)) * 0x94D049BB133111EBL;
        h ^= h >>> 31;
        return (h >>> 11) / (double) (1L << 53);
    }

    private SkyBreaker() {}
}
