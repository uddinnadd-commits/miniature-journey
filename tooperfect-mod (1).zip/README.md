# Too Perfect  (Forge 1.20.1 horror mod)

The world starts out peaceful. Too peaceful. Then it stops being a world.

| Stage | Name | What happens |
|---|---|---|
| 0 | Serenity | Flowers bloom everywhere, no monsters, no night, soft pollen in the air. Every animal turns its head to follow you. |
| 1 | Too Perfect | The sun freezes at noon, weather is always clear. Animals face you with their whole body and stop moving when you are near. Silence, then a faint stare sound now and then. |
| 2 | Fracture | A cracked glass sky appears high above the world and breaks piece by piece. Behind it is a thick black void that dims the light below. Glass cracks, ash falls, fog thickens. |
| 3 | Decay | Frozen blood-red dusk. Grass bleeds, flowers wither, trees rot into twisted rotten logs with branches and hanging tendrils. Animals and villagers mutate (stretched, twitching) and hunt you. |
| 4 | Unmaking | Midnight forever. Stone, dirt, sand and every other solid block turns into something wrong (corrupted stone, tainted earth, blocks covered in eyes). |

Your thoughts for each stage appear as typewriter text above the hotbar.

## Build it on GitHub
1. Upload the **contents** of this folder to the root of your repo (not the zip itself). `settings.gradle` and `.github/` must be at the top level.
2. Open the Actions tab. The "Build mod" workflow runs on every push, or click "Run workflow".
3. When it goes green, download the `tooperfect-jar` artifact. Inside is `tooperfect.jar`. Put it in your `mods` folder (Forge 1.20.1, 47.x).

The workflow also finds `settings.gradle` in a subfolder and will unpack a stray `.zip` if one was uploaded by mistake.

## Testing
Use a throwaway world, because the later stages rewrite blocks and they do not change back.

    /tooperfect stage <0-4>    jump to a stage (op level 2)
    /tooperfect info           current stage and progress

Pacing is `stageMinutes` in `config/tooperfect-common.toml` (default 15 real minutes per stage, counted only while a player is online). You can also turn off the sky, block corruption, mob mutation and flowers there.

## Notes
- Mutated mobs reuse the vanilla models, drawn stretched and twitching, flagged through the mob's left-handed bit so the client knows which ones to distort.
- Hostile spawns are blocked in stages 0 and 1.
- The glass sky is at Y=192 with 6 layers of void above it, within about 112 blocks of each player.
